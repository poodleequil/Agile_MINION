<form method="POST" action="index.php?mod=products&act=resultsearch">
    <input style="margin-top: 10px;margin-left: 20px;border: solid; border-color:#2D2520 ;border-radius: 10px;" type="text" placeholder="Nhập tên sản phẩm/Mã sản phẩm (Barcode)" name="txtSearch">
    <input style="background-color: #2D2520;border-radius: 10px;"type="submit" name="btnTimKiem" value="Tìm kiếm">
</form>