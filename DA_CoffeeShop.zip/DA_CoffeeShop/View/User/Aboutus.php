<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<section class="our-webcoderskull padding-lg">
  <div style="background-image: url('Images/bg.jpg')" class="container">
    <div class="row heading heading-icon">
        <h2 style="font-family: tahoma; font-weight: bold; color: #fff">My Team</h2>
    </div>
    <ul style="margin-left: 5px;" class="row">
      <li class="col-12 col-md-6 col-lg-3">
          <div class="cnt-block equal-hight" style="height: 349px;">
            <figure><img src="Images/ren3.jpg" class="img-responsive" alt=""></figure>
            <h3><a href="https://www.facebook.com/zyzyanhkim">Nguyễn Hoàng Anh</a></h3>
            <p style="font-weight: bold;color: #ff6600; font-size: 16px;">44.01.104.052</p>
            <ul class="follow-us clearfix">
              <li><a href="https://www.facebook.com/zyzyanhkim"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
              <li><a href="https://instagram.com/?lang=vi"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
              <li><a href="https://www.linkedin.com/"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
            </ul>
          </div>
      </li>
      <li class="col-12 col-md-6 col-lg-3">
          <div class="cnt-block equal-hight" style="height: 349px;">
            <figure><img src="Images/ren7.jpg" class="img-responsive" alt=""></figure>
            <h3><a href="https://www.facebook.com/">Lê Ngô Tuyết Trinh</a></h3>
            <p style="font-weight: bold;color: #ff6600; font-size: 16px">42.01.101.165</p>
            <ul class="follow-us clearfix">
              <li><a href="https://www.facebook.com"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
              <li><a href="https://instagram.com/?lang=vi"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
              <li><a href="https://www.linkedin.com/"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
            </ul>
          </div>
      </li>
      <li class="col-12 col-md-6 col-lg-3">
          <div class="cnt-block equal-hight" style="height: 349px;">
            <figure><img src="Images/ren6.jpg" class="img-responsive" alt=""></figure>
            <h3><a href="https://www.facebook.com">Võ Yến Nhi</a></h3>
            <p style="font-weight: bold;color: #ff6600; font-size: 16px">43.01.104.119</p>
            <ul class="follow-us clearfix">
              <li><a href="https://www.facebook.com"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
              <li><a href="https://instagram.com/?lang=vi"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
              <li><a href="https://www.linkedin.com/"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
            </ul>
          </div>
       </li>
       <li class="col-12 col-md-6 col-lg-3">
          <div class="cnt-block equal-hight" style="height: 349px;">
            <figure><img src="Images/ren4.jpg" class="img-responsive" alt=""></figure>
            <h3><a href="https://www.facebook.com/profile.php?id=100008530577426">Nguyễn Minh Thư</a></h3>
            <p style="font-weight: bold;color: #ff6600; font-size: 16px">4501103040</p>
            <ul class="follow-us clearfix">
              <li><a href="https://www.facebook.com/profile.php?id=100008530577426"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
              <li><a href="https://instagram.com/?lang=vi"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
              <li><a href="https://www.linkedin.com/"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
            </ul>
          </div>
       </li>
    </ul>
  </div>
</section>