<div style="width: 1000px; float: right; margin: 0 auto;">
<h2><span><a href="admin.php?mod=manufacturer&act=insert">Thêm chủ đề</a></span></h2>

  	<form class="form" method="post" action="admin.php?mod=manufacturer&act=insert">
        <p><label>Tên Chủ đề (*)</label><input type="text" name="txtManufacturerName" id="txtManufacturerName" /></p>
        <p><label>&nbsp;</label><input type="submit" value="Lưu" name="btnSave" id="btnSave" /></p>
        <p id="error" class="error"></p>
    </form>

</div>