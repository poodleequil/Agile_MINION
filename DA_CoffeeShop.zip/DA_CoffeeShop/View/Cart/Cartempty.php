<br>
<center><h2 class="section-title">Chi tiết giỏ hàng</h2></center>

<!-- End Page title area -->
    
<?php
 include_once("View/Products/Showleft.php");
 ?>  
<div class="single-product-area">
    <!-- <div class="zigzag-bottom"></div> -->
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="product-content-right">
                    <div class="woocommerce">
                        <form method="post" action="#">
                            <table cellspacing="0" class="shop_table cart">
                            <thead>
                                        <tr>
                                            <th class="product-remove">&nbsp;</th>
                                            <th class="product-thumbnail">Ảnh</th>
                                            <th class="product-name">Tên sản phẩm</th>
                                            <th class="product-price">Giá</th>
                                            <th class="product-quantity">Số lượng</th>
                                            <th class="product-remove">&nbsp;</th>
                                        </tr>
                            </thead>
                            <tbody >
                                        <tr style="height: 10px;">
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                            </tbody>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
            <center><a href="index.php?mod=products&act=allproducts" class="btn btn-primary" type="button" style="font-size: 30px; margin-bottom: 15px;">Mời bạn tiếp tục mua hàng!</a></center>

            
        </div>
    </div>
</div>