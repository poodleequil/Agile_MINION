<div class="container">

<div class="slider-area">
    <div class="block-slider block-slider4">
                <ul class="" id="bxslider-home4">
                    <li>
                        <a href="index.php?mod=products&act=allproducts"><img  src="Images/carousel_01.png" alt="Slide"></a>
                        <div class="caption-group">
                            <a class="caption button-radius" href="index.php?mod=products&act=allproducts"><span class="icon"></span>Shop now</a>
                        </div>
                    </li>
                    <li>
                        <a href="index.php?mod=products&act=allproducts"><img src="Images/carousel_02.png" alt="Slide"></a>
                        <div class="caption-group">
                            <a class="caption button-radius" href="index.php?mod=products&act=allproducts"><span class="icon"></span>Shop now</a>
                        </div>
                    </li>
                    <li>
                        <a href="index.php?mod=products&act=allproducts"><img src="Images/carousel_03.jpg" alt="Slide"></a>
                        <div class="caption-group">
                            <a class="caption button-radius" href="index.php?mod=products&act=allproducts"><span class="icon"></span>Shop now</a>
                        </div>
                    </li>
                    <li>
                        <a href="index.php?mod=products&act=allproducts"><img src="Images/carousel_04.png" alt="Slide"></a>
                        <div class="caption-group">
                            <a class="caption button-radius" href="index.php?mod=products&act=allproducts"><span class="icon"></span>Shop now</a>
                        </div>
                    </li>
                    <li>
                        <a href="index.php?mod=products&act=allproducts"><img src="Images/carousel_05.png" alt="Slide"></a>
                        <div class="caption-group">
                            <a class="caption button-radius" href="index.php?mod=products&act=allproducts"><span class="icon"></span>Shop now</a>
                        </div>
                    </li>
                </ul>
            </div>
            <!-- ./Slider -->
    </div>
     <!-- End slider area -->
     </div> 